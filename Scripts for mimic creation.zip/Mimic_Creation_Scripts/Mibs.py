import os
from datetime import datetime

# How to run the Script:                                                                                   
# python3 Mibs.py                                       



def commands():
    # Open the simcommandPath file and read its content into lines
    with open(FilesPath + '/simcommand', 'r') as file:
        lines = file.readlines()
    # Print a success message
    print('Simcommand loaded Successfully')

    # Initialize an empty list
    listofNames = []

    start = False
    # Loop through each line in lines
    for line in lines:
        # Check if the line contains 'line 0'
        if 'line 0' in line:
            # Set start to True
            start = True
            # Continue to the next iteration of the loop
            continue
        # Check if the line contains '--source '
        if '--source ' in line:
            # Set start to False
            start = False
        # Check if start is True
        if start:
            # Split the line by "--force " and take the second element, then split it by " \"
            # and take the first element, and assign it to f
            f = line.split("--force ")[1].split(" \\")[0]

            # Check if NameimportFolder is in f and MimicWithversion is not in f
            if NameimportFolder in f and not MimicWithversion in f:
                # Split the line by NameimportFolder + "/" and take the second element,
                # then split it by " " and take the first element, and assign it to f
                f = line.split(NameimportFolder + "/")[1].split(" ")[0]

            # Check if NameimportFolder and MimicWithversion are both in f
            elif NameimportFolder in f and MimicWithversion in f:
                # Split the line by NameimportFolder + "/" and take the second element,
                # then split it by "_" + MimicWithversion and take the first element,
                # then split it by " " and take the first element, and assign it to f
                f = line.split(NameimportFolder + "/")[1].split("_" + MimicWithversion )[0].split(" ")[0]

            # Check if f is equal to 'SNMP-TARGET-MIB' and 'SNMP-TARGET-MIB' is already in listofNames
            if f == 'SNMP-TARGET-MIB' and 'SNMP-TARGET-MIB' in listofNames:
                # Set f to 'ICOM-SNMP-TARGET-MIB'
                f = 'ICOM-SNMP-TARGET-MIB'

            # Append f to listofNames
            listofNames.append(f)
    # Initialize an empty list to store the command strings for each MIB file
    listofCommands = []


    print('Files loaded Successfully')

    # Iterate over each element in the list of names
    for element in listofNames:
        # If the name contains 'ATM-FORUM-SNMP-M4-MIB', replace it with 'ICOM-ATM-FORUM-SNMP-M4-MIB'
        if  'ATM-FORUM-SNMP-M4-MIB' in element:
            element = 'ICOM-ATM-FORUM-SNMP-M4-MIB'
        # If the name contains 'ICOM-Y1731-PM-MIB', replace it with 'ICOM-Y1731-PM'
        if  'ICOM-Y1731-PM-MIB' in element:
            element = 'ICOM-Y1731-PM'
        # If the name contains 'ICOM-SNMP-TARGET-MIB', replace it with 'ICOM-SNMP-TARGET'
        if  'ICOM-SNMP-TARGET-MIB' in element:
            element = 'ICOM-SNMP-TARGET' 
        # If the name contains 'Q-BRIDGE-MIB', skip it and continue to the next iteration

        # If the name contains 'ICOM-EtherLike-MIB', replace it with 'ICOM-ETHERLIKE-MIB'
        if 'ICOM-EtherLike-MIB' in element:
            element = 'ICOM-ETHERLIKE-MIB'
        # Convert the name to lowercase and replace '-' with '_'
        if 'IEEE8021-CFM-MIB_mib' in element:
            element =  'IEEE8021-CFM-MIB_mib_' + MimicWithversion
        lower = element.lower()
        lower = lower.replace("-","_") 
        # Iterate over the list of files
        for file in mib_files:
            file = mib_files[file]
            # Check if 'lower' is a substring of the file name
            if lower in file:
                # Set 'element' to 'lower'
                element = lower

            # # Check if 'element' is equal to 'P-BRIDGE-MIB' and if 'QP-BRIDGE-4363.wri' is a substring of the file name
            # if element == 'P-BRIDGE-MIB' and 'QP-BRIDGE-4363.wri'in file:   
            #     # Append the file to 'listofCommands'
            #     listofCommands.append(file)

            # Check if the file name starts with 'element' and if 'element' is a substring of the file name
            if file.startswith(element) and element in file:
                # Append the file to 'listofCommands'
                if 'QP-BRIDGE-4363.wri' in file:
                    continue 
                listofCommands.append(file)

    # Create an empty list called 'notCompiled'
    notCompiled = []

    # Iterate over 'listofCommands'
    for command in listofCommands:
        # Check if 'command' is in the list of files
        if command in reverse.keys():
            
            # Append 'command' to 'notCompiled'
            notCompiled.append(command)


    print('\nThe following files were inside the Mibs, but did not produce any command. If they are needed edit the code or add them manually.\n')
    print('-------------------------------------------------------------\n')

    # Iterate over the list of files
    for f in reverse.keys():
        # Check if 'f' is not in 'notCompiled'
        if f not in notCompiled:
            # Print the name of the file
            if 'QP-BRIDGE-' in f:
                continue 
            print(f)

    # Print a separator line
    print('-------------------------------------------------------------\n')

    for i, command in enumerate(listofCommands): # loop through list of commands and their indices
        command = command.replace('\n', '') # remove newline characters from command
        importer = "cp -f " + command + " /home/mimic/mimic/mibs/" + NameimportFolder + "/" + "\n\n" # create command to copy file to mimic/mibs directory
        dontcompile = {'SNMPv2-SMI-rfc2578.txt','SNMPv2-TC-rfc2579.txt','SNMPv2-CONF-rfc2580.txt'} # create set of files that should not be compiled
        if SNMPv2 == "y" : # if user input is "y", clear set of files that should not be compiled
            dontcompile.clear()
        if command in dontcompile: # if command is in set of files that should not be compiled
            listofCommands[i] = importer # add copy command to list of commands
        else: 
            listofCommands[i] = importer + "/opt/mimic/bin/mimiccom " + NameimportFolder + "/" + command + "\n\n" # add copy command and mimiccom command to list of commands
        if '\n' not in listofCommands[i]: # if newline character is not already in command
            listofCommands[i] += "\n" # add newline character to end of command

    with open(FilesPath + 'commands.txt', 'w') as f: # open commands.txt file for writing
        for item in listofCommands: # loop through list of commands
            f.write("%s" % item) # write command to commands.txt file

    print('Commands were created successfully')



def editMibs():
    add = '_'+ MimicWithversion
    MibsToChange = {}
    for file in mib_files.keys():
        editFile = []
        with open(file, 'r') as f:
            imports = False
            stop = True
            
            for line in f:
                if 'IMPORTS' in line:
                    imports = True
                if 'ICOM' in file and 'DEFINITIONS ::= BEGIN' in line:
                        if 'ICOM' not in line:
                            temp = line.strip()
                            line = ''
                            line = 'ICOM-' + temp + '\n'
                            MibsToChange[temp.split(' ')[0]] =  line.split(' ')[0] + add
                            
                if 'ICOM-' in line and '--' not in line and add not in line and stop:
                    t = line.strip()
                    t = t.split(' ')
                    index = 0
                    for i in t:
                        if 'ICOM-' not in t[index]:
                            index +=1
                        else:
                            break
                    if ';' in t[index]:
                        t[index] = t[index].replace(';','')
                        t[index]= t[index].replace(t[index],t[index]+add + ';')
                    elif ')' in t[index]:
                        t[index] = t[index].replace(')','')
                        t[index]= t[index].replace(t[index],t[index]+add + ')')
                    elif '"' in t[index]:
                        t[index] = t[index].replace('"','')
                        t[index]= t[index].replace(t[index],t[index]+add + '"')
                    elif '.' in t[index]:
                        t[index] = t[index].replace('.','')
                        t[index]= t[index].replace(t[index],t[index]+add + '.')
                    else:
                        t[index] = t[index].replace(t[index],t[index]+add)

                    line = ''
                    if imports:
                        line = '\t'
                    for word in t:
                        line += word + ' '
                    line += '\n'
                    editFile.append(line)
                else:
                    editFile.append(line)

                if ';' in line :
                    stop = False
        with open(file, 'w') as f: 
            for item in editFile: 
                f.write("%s" % item)  
    for file in mib_files.keys():
        editFile = []
        with open(file, 'r') as f:
            for line in f:
                    if '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' in line: 
                        line = ' DEFVAL { 0 }'
                    
                    if 'IEEE8021-CFM-MIB_mib' in file:
                        if 'standards-association-numbered-series-standards (2)' in line:
                            line = line.replace('(2)', '(22)')
                            
                    editFile.append(line)
                    if 'DEFINITIONS ::= BEGIN' in line:
                        continue
                    for key in MibsToChange.keys():
                        if key in line:
                            editFile.pop(-1)
                            line = line.replace(key,MibsToChange[key])
                            editFile.append(line)

        with open(file, 'w') as f: 
            for item in editFile: 
                f.write("%s" % item)  

def createSimcommand():

    mibs = mib_files.copy()
    problem = ''
    for key in mib_files.keys():
        if 'QP-BRIDGE-4363.wri' in mib_files[key]:
            problem = key
            qBridge = []
            pBridge = []
            change = False
            with open(key, 'r') as f:
                for line in f:
                    if 'Q-BRIDGE-MIB DEFINITIONS ::= BEGIN' in line:
                        change = True
                    if change:
                        qBridge.append(line)
                    else: 
                        pBridge.append(line)
            with open(FilesPath+'/Q-BRIDGE-MIB.wri', 'w') as f: 
                for item in qBridge: 
                    f.write("%s" % item) 

            with open(FilesPath+'/P-BRIDGE-MIB.wri', 'w') as f: 
                for item in pBridge: 
                    f.write("%s" % item) 
            mibs.pop(key)
            mibs[FilesPath+'/Q-BRIDGE-MIB.wri'] = 'Q-BRIDGE-MIB'
            mibs[FilesPath+'/P-BRIDGE-MIB.wri'] = 'P-BRIDGE-MIB'
    clear()
    initPaths()
    mibs.clear()
    mibs = mib_files.copy()
    if problem != '':
        mibs.pop(problem)

    for file in mibs.keys():
        with open(file, 'r') as f:
            imports = []
            inside_imports = False
            for line in f:
                if 'IMPORTS' in line:
                    inside_imports = True
                if inside_imports:
                    if 'FROM ' in line:
                        parts = line.split("FROM")
                        if len(parts) > 1:
                            module_names = parts[1].split()
                            imp = module_names[0]
                            if ';' in imp:
                                imp =  imp.rstrip(';')
                            imports.append(imp)
                if ';' in line:
                    inside_imports = False

        dependencies[mibs[file]] = imports


    # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    # DFS                                                   #
    #                                                       #
    # The code first checks whether the current node has    #
    #  already been visited, and if not, it adds it to the  #
    #  set of visited nodes. Then, it checks if the current #
    #  node has any neighbors (i.e., nodes that it depends  #
    #  on), and if so, it loops over them. For each neighbor#
    #  it first checks if it has not already been processed #
    #  (i.e., it is not in the help dictionary), and if it  #
    #  is not in the sorted_list. If these conditions are   #
    #  met, it adds the neighbor to the sorted list. If the #
    #  neighbor has already been processed, it updates the  #
    #  neighbor variable to the file it belongs to, and     #
    #  recursively calls the DFS function on that file.     #
    #  Finally,the current node is added to the sorted list. #
    # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    def dfs(node, visited, dependencies, sorted_list, help):

        if node not in visited:
            visited.add(node)
            if node in dependencies.keys():
                for neighbor in dependencies[node]:
                    if neighbor not in help.keys():
                        if neighbor not in sorted_list:
                            sorted_list.append(neighbor)
                    if neighbor in help.keys():
                        neighbor = help[neighbor]
                        dfs(neighbor, visited, dependencies, sorted_list, help)
                sorted_list.append(node)

    def sort_by_imports(dependencies, help):
        sorted_list = []
        visited = set()
        for node in dependencies:

            dfs(node, visited, dependencies, sorted_list,help)
        return sorted_list

    # Sort files based on their dependencies
    result = sort_by_imports(dependencies, help)
    # for file in result:
    #     print(file)
    importedMibs = ['PTPBASE-MIB','IEEE8021-BRIDGE-MIB','IEEE8023-EtherLike-MIB','IEEE8021-CFM-MIB','LLDP-MIB','SNMP-USER-BASED-SM-MIB','SNMP-USM-HMAC-SHA2-MIB']
    simcommand = []
    simcommand.append('/opt/mimic/bin/mimicrec \\\n')
    simcommand.append('--file'+ WalkPath +  '/' + IP + '_public.txt \\\n')
    simcommand.append('--simulation sim.'+NameimportFolder+'_public.'+datetime.now().strftime("%Y%m%d")+ ' \\\n')
    simcommand.append('--scenario 1 \\\n')
    simcommand.append('--method random \\\n')
    simcommand.append('--line 0 \\\n')
    for file in result:
        edit = '--force '
        if 'ICOM' in file:
            #print(file)
            edit += NameimportFolder + '/'
        else:
            for mib in importedMibs:
                if mib in file:
            #if 'SNMP-TARGET' in file or 'PTPBASE-MIB' in file or 'IEEE8021-BRIDGE-MIB' in file or 'IEEE8021-CFM-MIB' in file or 'LLDP-MIB' in file or 'SNMP-USER-BASED-SM-MIB' in file:
                        edit += NameimportFolder + '/'

        if file in reverse.keys(): 
            edit += reverse[file] + ' \\\n'
        else :     
            edit += file + ' \\\n' 
        # if 'IEEE8021-CFM-MIB' in edit:
        #     edit =  '--force +'+ NameimportFolder +'/IEEE8021-CFM-MIB_' + MimicWithversion + ' \\\n'
        if 'SNMP-VIEW-BASED-ACM-MIB' in edit and 'y' in SNMPview: 
            continue
        simcommand.append(edit)

    simcommand.append('--source \\\n')
    simcommand.append('--overwrite')

    with open(FilesPath+'/simcommand', 'w') as f: 
        for item in simcommand: 
            f.write("%s" % item) 

    print('simcommand were created successfully')



def clear():
    mib_files.clear()
    dependencies.clear()
    help.clear()
    reverse.clear()
def initPaths():
    for dirpath, dirnames, filenames in os.walk(FilesPath):
        for filename in filenames:
            if 'bashscript' in filename or 'simcommand' in filename or 'commands' in filename :
                continue
            mib_files.update({os.path.join(dirpath, filename) : filename})

    for file in mib_files.keys():
        with open(file, 'r') as f:
            for line in f:
                if 'BEGIN' in line:
                    line = line.strip()
                    name = line.split(' ')[0]
                    help[name] = mib_files[file]
                    reverse[mib_files[file]] = name
                    break



FilesPath = input("Enter the absolute Path of your mibs: ") 


NameimportFolder= input("Enter your folder name in the jameson with you mimic Device that is located at /home/mimic/mimic/mibs/'thisName'/: ")

MimicWithversion = input("Enter your mimic name with Version: ")


WalkPath = input("Enter the absolute walk path in jameson. Ex: /home/mimic/prjs/WIBAS_G5_Dual_BS/6.2.0/walks/ : ")

IP = input("Enter your real element IP : ")

SNMPv2 = input("Do you want to compile all the SNMPv2 or only the SNMPv2-MIB? Answer with y/n (You probably want them):  ")

SNMPview = input("Do you want SNMP-VIEW-BASED-ACM-MIB? Answer with y/n (You probably do not want it):  ")

IP = IP.replace('.','_')
SNMPv2 = SNMPv2.lower()
SNMPview = SNMPview.lower()
mib_files = {}
dependencies = {}
help = {}
reverse = {}
mibs = False

initPaths()

for file in mib_files.keys():
    if 'LLDP-MIB.' in file:
        mibs = True


if mibs:
    editMibs()
    createSimcommand()
    commands()
    print('Commands and Simcommand were created successfully')
    print('Edit the first lines of the simcommand, your jameson mib and walk Paths, date and element IP')
else:
    print('LLDP-MIB mib is missing, add it in your mibs, or edit the last lines of the code.')